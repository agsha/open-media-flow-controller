/*
 * This file is part of the Chelsio T3 Ethernet driver.
 *
 * Copyright (C) 2009 Chelsio Communications.  All rights reserved.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the LICENSE file included in this
 * release for licensing terms and conditions.
 */

#include "common.h"
#include "regs.h"

/*
 * Search for this in the entire file and fix each code block before release.
 */

#undef AQ_USE_INTERRUPTS

enum {
	/* MDIO_DEV_PMA_PMD registers */
	AQ_LINK_STAT	= 0xe800,
	AQ_IMASK_PMA	= 0xf000,

	/* MDIO_DEV_XGXS registers */
	AQ_XAUI_RX_CFG	= 0xc400,
	AQ_XAUI_TX_CFG	= 0xe400,

	/* MDIO_DEV_ANEG registers */
	AQ_100M_CTRL	= 0x0010,
	AQ_10G_CTRL	= 0x0020,
	AQ_1G_CTRL	= 0xc400,
	AQ_ANEG_STAT	= 0xc800,

	/* MDIO_DEV_VEND1 registers */
	AQ_FW_VERSION	= 0x0020,
	AQ_THERMAL1	= 0xc820,
	AQ_THERMAL2	= 0xc821,
	AQ_IFLAG_GLOBAL	= 0xfc00,
	AQ_IMASK_GLOBAL	= 0xff00,
};

#define AQBIT(x)	(1 << (x))
#define IMASK_PMA	AQBIT(0x2)
#define IMASK_GLOBAL	AQBIT(0xf)
#define ADV_1G_FULL	AQBIT(0xf)
#define ADV_1G_HALF	AQBIT(0xe)
#define ADV_10G_FULL	AQBIT(0xc)
#define AQ_RESET	(AQBIT(0xe) | AQBIT(0xf))
#define AQ_LOWPOWER	AQBIT(0xb)

#if 0
/*
 * Return value is temperature in celcius, 0xffff for error or don't know.
 */
static int
aq100x_temperature(struct cphy *phy)
{
	int v;

	if (mdio_read(phy, MDIO_DEV_VEND1, AQ_THERMAL2, &v) ||
	    v == 0xffff || (v & 1) != 1)
		return (0xffff);

	if (mdio_read(phy, MDIO_DEV_VEND1, AQ_THERMAL1, &v))
		return (0xffff);

	return ((int)((signed char)(v >> 8)));
}
#endif

static int
aq100x_reset(struct cphy *phy, int wait)
{
	int err;

#ifdef AQ_USE_INTERRUPTS
	unsigned int imask = 0;

	err = mdio_read(phy, MDIO_DEV_VEND1, AQ_IMASK_GLOBAL, &imask);
	if (err)
		return (err);
#endif

	/*
	 * Ignore the caller specified wait time; always wait for the reset to
	 * complete.  Can take upto 3s.
	 */
	err = t3_phy_reset(phy, MDIO_DEV_VEND1, 3000);
	if (err) {
		CH_WARN(phy->adapter, "PHY%d: reset failed (0x%x).\n",
			phy->addr, err);
		return (err);
	}

#ifdef AQ_USE_INTERRUPTS
	if (imask && imask != 0xffff)
		err = mdio_write(phy, MDIO_DEV_VEND1, AQ_IMASK_GLOBAL, imask);
#endif

	return (err);
}

static int
aq100x_intr_enable(struct cphy *phy)
{
	int err;

	err = mdio_write(phy, MDIO_DEV_PMA_PMD, AQ_IMASK_PMA, IMASK_PMA);
	if (err)
		return (err);

	err = mdio_write(phy, MDIO_DEV_VEND1, AQ_IMASK_GLOBAL, IMASK_GLOBAL);
	return (err);
}

static int
aq100x_intr_disable(struct cphy *phy)
{
	return mdio_write(phy, MDIO_DEV_VEND1, AQ_IMASK_GLOBAL, 0);
}

static int
aq100x_intr_clear(struct cphy *phy)
{
	unsigned int v;

	(void) mdio_read(phy, MDIO_DEV_VEND1, AQ_IFLAG_GLOBAL, &v);
	(void) mdio_read(phy, MDIO_DEV_PMA_PMD, MII_BMSR, &v);

	return (0);
}

static int
aq100x_intr_handler(struct cphy *phy)
{
	int err;
	unsigned int cause, v;

	err = mdio_read(phy, MDIO_DEV_VEND1, AQ_IFLAG_GLOBAL, &cause);
	if (err)
		return (err);

	/* Read (and reset) the latching version of the status */
	(void) mdio_read(phy, MDIO_DEV_PMA_PMD, MII_BMSR, &v);

	return (cphy_cause_link_change);
}

static int
aq100x_power_down(struct cphy *phy, int off)
{
	return t3_mdio_change_bits(phy, MDIO_DEV_PMA_PMD, MII_BMCR, BMCR_PDOWN,
				   off ? BMCR_PDOWN : 0);
}

static int
aq100x_autoneg_enable(struct cphy *phy)
{
	int err;
	unsigned int clr = 0;

#ifdef AQ_USE_INTERRUPTS
	/*
	 * Not sure why, but interrupt masks are cleared if this bit is 1 when
	 * we write to mmd 7
	 */
	clr = BMCR_RESET;
#endif

	err = aq100x_power_down(phy, 0);
	if (!err)
		err = t3_mdio_change_bits(phy, MDIO_DEV_ANEG, MII_BMCR, clr,
					  BMCR_ANENABLE | BMCR_ANRESTART);

	return (err);
}

static int
aq100x_autoneg_restart(struct cphy *phy)
{
	int err;
	unsigned int clr = 0;

#ifdef AQ_USE_INTERRUPTS
	/*
	 * Not sure why, but interrupt masks are cleared if this bit is 1 when
	 * we write to mmd 7
	 */
	clr = BMCR_RESET;
#endif
	err = aq100x_power_down(phy, 0);
	if (!err)
		err = t3_mdio_change_bits(phy, MDIO_DEV_ANEG, MII_BMCR,
					  clr, BMCR_ANRESTART);

	return (err);
}

static int
aq100x_advertise(struct cphy *phy, unsigned int advertise_map)
{
	unsigned int adv;
	int err;

	/* 10G advertisement */
	adv = 0;
	if (advertise_map & ADVERTISED_10000baseT_Full)
		adv |= ADV_10G_FULL;
	err = t3_mdio_change_bits(phy, MDIO_DEV_ANEG, AQ_10G_CTRL,
				  ADV_10G_FULL, adv);
	if (err)
		return (err);

	/* 1G advertisement */
	adv = 0;
	if (advertise_map & ADVERTISED_1000baseT_Full)
		adv |= ADV_1G_FULL;
	if (advertise_map & ADVERTISED_1000baseT_Half)
		adv |= ADV_1G_HALF;
	err = t3_mdio_change_bits(phy, MDIO_DEV_ANEG, AQ_1G_CTRL,
				  ADV_1G_FULL | ADV_1G_HALF, adv);
	if (err)
		return (err);

	/* 100M, pause advertisement */
	adv = 0;
	if (advertise_map & ADVERTISED_100baseT_Half)
		adv |= ADVERTISE_100HALF;
	if (advertise_map & ADVERTISED_100baseT_Full)
		adv |= ADVERTISE_100FULL;
	if (advertise_map & ADVERTISED_Pause)
		adv |= ADVERTISE_PAUSE_CAP;
	if (advertise_map & ADVERTISED_Asym_Pause)
		adv |= ADVERTISE_PAUSE_ASYM;
	err = t3_mdio_change_bits(phy, MDIO_DEV_ANEG, AQ_100M_CTRL, 0xfe0, adv);

	return (err);
}

static int
aq100x_set_loopback(struct cphy *phy, int mmd, int dir, int enable)
{
	return t3_mdio_change_bits(phy, MDIO_DEV_PMA_PMD, MII_BMCR,
				   BMCR_LOOPBACK, enable ? BMCR_LOOPBACK : 0);
}

static int
aq100x_set_speed_duplex(struct cphy *phy, int speed, int duplex)
{
	/* no can do */
	return (-1);
}

static int
aq100x_get_link_status(struct cphy *phy, int *link_ok, int *speed, int *duplex,
		       int *fc)
{
	int err;
	unsigned int v;

	if (link_ok) {
		err = mdio_read(phy, MDIO_DEV_PMA_PMD, AQ_LINK_STAT, &v);
		if (err)
			return (err);

		*link_ok = v & 1;
		if (!*link_ok)
			return (0);
	}

	err = mdio_read(phy, MDIO_DEV_ANEG, AQ_ANEG_STAT, &v);
	if (err)
		return (err);

	if (speed) {
		switch (v & 0x6) {
		case 0x6: *speed = SPEED_10000;
			break;
		case 0x4: *speed = SPEED_1000;
			break;
		case 0x2: *speed = SPEED_100;
			break;
		case 0x0: *speed = SPEED_10;
			break;
		}
	}

	if (duplex)
		*duplex = v & 1 ? DUPLEX_FULL : DUPLEX_HALF;

	return (0);
}

static struct cphy_ops aq100x_ops = {
	.reset             = aq100x_reset,
	.intr_enable       = aq100x_intr_enable,
	.intr_disable      = aq100x_intr_disable,
	.intr_clear        = aq100x_intr_clear,
	.intr_handler      = aq100x_intr_handler,
	.autoneg_enable    = aq100x_autoneg_enable,
	.autoneg_restart   = aq100x_autoneg_restart,
	.advertise         = aq100x_advertise,
	.set_loopback      = aq100x_set_loopback,
	.set_speed_duplex  = aq100x_set_speed_duplex,
	.get_link_status   = aq100x_get_link_status,
	.power_down        = aq100x_power_down,
};

int
t3_aq100x_phy_prep(pinfo_t *pinfo, int phy_addr,
		       const struct mdio_ops *mdio_ops)
{
	struct cphy *phy = &pinfo->phy;
	unsigned int v, v2, gpio, wait;
	int err;
	adapter_t *adapter = pinfo->adapter;

	cphy_init(&pinfo->phy, adapter, pinfo, phy_addr, &aq100x_ops, mdio_ops,
		  SUPPORTED_1000baseT_Full | SUPPORTED_10000baseT_Full |
		  SUPPORTED_TP | SUPPORTED_Autoneg | SUPPORTED_AUI |
		  SUPPORTED_MISC_IRQ, "1000/10GBASE-T");

	/*
	 * The PHY has been out of reset ever since the system powered up.  So
	 * we do a hard reset over here.
	 */
	gpio = phy_addr ? F_GPIO10_OUT_VAL : F_GPIO6_OUT_VAL;
	t3_set_reg_field(adapter, A_T3DBG_GPIO_EN, gpio, 0);
	msleep(1);
	t3_set_reg_field(adapter, A_T3DBG_GPIO_EN, gpio, gpio);

#ifdef AQ_USE_INTERRUPTS
	phy->caps |= SUPPORTED_IRQ;
#endif

	/*
	 * Give it enough time to load the firmware and get ready for mdio.
	 */
	msleep(1000);
	wait = 500; /* in 10ms increments */
	do {
		err = mdio_read(phy, MDIO_DEV_VEND1, MII_BMCR, &v);
		if (err || v == 0xffff) {

			/* Allow prep_adapter to succeed when ffff is read */

			CH_WARN(adapter, "PHY%d: reset failed (0x%x, 0x%x).\n",
				phy_addr, err, v);
			goto done;
		}

		v &= AQ_RESET;
		if (v)
			msleep(10);
	} while (v && --wait);
	if (v) {
		CH_WARN(adapter, "PHY%d: reset timed out (0x%x).\n",
			phy_addr, v);

		goto done; /* let prep_adapter succeed */
	}

	/* Datasheet says 3s max but this has been observed */
	wait = (500 - wait) * 10 + 1000;
	if (wait > 3000)
		CH_WARN(adapter, "PHY%d: reset took %ums\n", phy_addr, wait);

	/* Firmware version check. */
	(void) mdio_read(phy, MDIO_DEV_VEND1, AQ_FW_VERSION, &v);
	if (v != 0x101)
		CH_WARN(adapter, "PHY%d: unknown firmware %d\n", phy_addr, v);

	/*
	 * The PHY should start in really-low-power mode.  Prepare it for normal
	 * operations.
	 */
	err = mdio_read(phy, MDIO_DEV_VEND1, MII_BMCR, &v);
	if (err)
		return (err);
	if (v & AQ_LOWPOWER) {
		err = t3_mdio_change_bits(phy, MDIO_DEV_VEND1, MII_BMCR,
					  AQ_LOWPOWER, 0);
		if (err)
			return (err);
		msleep(10);
	} else
		CH_WARN(adapter, "PHY%d does not start in low power mode.\n",
			phy_addr);

	/*
	 * Verify XAUI settings, but let prep succeed no matter what.
	 */
	v = v2 = 0;
	(void) mdio_read(phy, MDIO_DEV_XGXS, AQ_XAUI_RX_CFG, &v);
	(void) mdio_read(phy, MDIO_DEV_XGXS, AQ_XAUI_TX_CFG, &v2);
	if (v != 0x1b || v2 != 0x1b)
		CH_WARN(adapter, "PHY%d: incorrect XAUI settings (0x%x, 0x%x).\n",
			phy_addr, v, v2);

done:
	return (err);
}
