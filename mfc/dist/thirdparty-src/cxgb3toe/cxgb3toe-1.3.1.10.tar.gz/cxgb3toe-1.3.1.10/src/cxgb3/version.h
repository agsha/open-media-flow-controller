/*****************************************************************************
 *                                                                           *
 * File:                                                                     *
 *  version.h                                                                *
 *                                                                           *
 * Description:                                                              *
 *  Chelsio driver version defines.                                          *
 *                                                                           *
 * Copyright (c) 2003 - 2009 Chelsio Communications, Inc.                    *
 * All rights reserved.                                                      *
 *                                                                           *
 * Maintainers: maintainers@chelsio.com                                      *
 *                                                                           *
 * http://www.chelsio.com                                                    *
 *                                                                           *
 ****************************************************************************/
/* $Date: 2008/08/07 02:39:03 $ $RCSfile: version.h,v $ $Revision: 1.5.4.1 $ */
#ifndef __CHELSIO_VERSION_H
#define __CHELSIO_VERSION_H
#define DRV_DESC "Chelsio T3 Network Driver"
#define DRV_NAME "cxgb3"
// Driver version
#ifndef DRV_VERSION
#define DRV_VERSION "1.3.1.10"
#endif
#endif //__CHELSIO_VERSION_H
