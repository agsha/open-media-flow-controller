/*
 * Copyright (C) 2003-2009 Chelsio Communications.  All rights reserved.
 *
 * Written by Dimitris Michailidis (dm@chelsio.com)
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the LICENSE file included in this
 * release for licensing terms and conditions.
 */

#ifndef _NET_OFFLOAD_H
#define _NET_OFFLOAD_H

#include <net/tcp.h>

#if defined(CONFIG_TCP_OFFLOAD_MODULE)
# define SOCK_OFFLOADED (31)		// connected socket is offloaded
# define SOCK_NO_DDP	(30)		// socket should not do DDP
#endif

enum {
	OFFLOAD_LISTEN_START,
	OFFLOAD_LISTEN_STOP
};

struct sock;
struct sk_buff;
struct toedev;
struct notifier_block;
struct pipe_inode_info;

/*
 * Extended 'struct proto' with additional members used by offloaded
 * connections.
 */
struct sk_ofld_proto {
	struct proto proto;    /* keep this first */
	int (*read_sock)(struct sock *sk, read_descriptor_t *desc,
			 sk_read_actor_t recv_actor);
	ssize_t (*splice_read)(struct sock *sk, loff_t *ppos,
			       struct pipe_inode_info *pipe, size_t len,
			       unsigned int flags);
};

/* Per-skb backlog handler.  Run when a socket's backlog is processed. */
struct blog_skb_cb {
	void (*backlog_rcv) (struct sock *sk, struct sk_buff *skb);
	struct toedev *dev;
};

#define BLOG_SKB_CB(skb) ((struct blog_skb_cb *)(skb)->cb)

#ifndef LINUX_2_4
struct offload_req {
	__be32 sip[4];
	__be32 dip[4];
	__be16 sport;
	__be16 dport;
	__u8   ipvers_opentype;
	__u8   tos;
	__be16 vlan;
	__u32  mark;
};

enum { OPEN_TYPE_LISTEN, OPEN_TYPE_ACTIVE, OPEN_TYPE_PASSIVE };

struct offload_settings {
	__u8  offload;
	__s8  ddp;
	__s8  rx_coalesce;
	__s8  cong_algo;
	__s32 rssq;
	__s16 sched_class;
	__s8  tstamp;
	__s8  sack;

};

struct ofld_prog_inst {          /* offload policy program "instructions" */
	s32 offset;
	u32 mask;
	u32 value;
	s32 next[2];
};

struct offload_policy {
	struct rcu_head rcu_head;
	int match_all;
	int use_opt;
	const struct offload_settings *settings;
	const u32 *opt_prog_start;
	struct ofld_prog_inst prog[0];
};

struct ofld_policy_file {
	unsigned int vers;
	int output_everything;
	unsigned int nrules;
	unsigned int prog_size;
	unsigned int opt_prog_size;
	unsigned int nsettings;
	const struct ofld_prog_inst prog[0];
};
#endif /* !LINUX_2_4 */

#if defined(CONFIG_TCP_OFFLOAD) || \
    (defined(CONFIG_TCP_OFFLOAD_MODULE) && defined(MODULE))
extern int register_listen_offload_notifier(struct notifier_block *nb);
extern int unregister_listen_offload_notifier(struct notifier_block *nb);
extern int start_listen_offload(struct sock *sk);
extern int stop_listen_offload(struct sock *sk);
extern int tcp_connect_offload(struct sock *sk);
extern int set_offload_policy(struct toedev *dev,
			      const struct ofld_policy_file *f);
extern void offload_req_from_sk(struct offload_req *req, struct sock *sk,
				int otype);
extern const struct offload_settings *
lookup_ofld_policy(const struct toedev *dev, const struct offload_req *req,
		   int cop_default);
extern void security_inet_conn_estab(struct sock *sk, struct sk_buff *skb);
extern void walk_listens(struct toedev *dev,
			 int (*func)(struct toedev *dev, struct sock *sk));
#else
static inline int tcp_connect_offload(struct sock *sk)
{
	return 0;
}

static inline int start_listen_offload(struct sock *sk)
{
	return -EPROTONOSUPPORT;
}

static inline int stop_listen_offload(struct sock *sk)
{
	return -EPROTONOSUPPORT;
}
#endif

#if defined(CONFIG_TCP_OFFLOAD_MODULE)
extern int  install_special_data_ready(struct sock *sk);
extern void restore_special_data_ready(struct sock *sk);
extern int  skb_splice_bits_pub(struct sk_buff *skb, unsigned int offset,
				struct pipe_inode_info *pipe, unsigned int len,
				unsigned int flags);
#else
static inline int install_special_data_ready(struct sock *sk) { return 0; }
static inline void restore_special_data_ready(struct sock *sk) {}
#define skb_splice_bits_pub skb_splice_bits
#endif

#if defined(CONFIG_DEBUG_RODATA) && defined(CONFIG_TCP_OFFLOAD_MODULE)
extern void offload_socket_ops(struct sock *sk);
extern void restore_socket_ops(struct sock *sk);
#else
static inline void offload_socket_ops(struct sock *sk) {}
static inline void restore_socket_ops(struct sock *sk) {}
#endif

#endif /* !_NET_OFFLOAD_H */
