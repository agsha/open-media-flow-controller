/*
 * Copyright (c) 2007-2009 Chelsio, Inc. All rights reserved.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the LICENSE file included in this
 * release for licensing terms and conditions.
 */
#ifndef __TOE_COMPAT_2_4_H
#define __TOE_COMPAT_2_4_H

#include <linux/version.h>

/* XXX Only built against 2.4.21 */
#if LINUX_VERSION_CODE != KERNEL_VERSION(2,4,21)
#endif

/******************************************************************************
 * socket compatibility
 * map 2.6 field names to 2.4 names
 ******************************************************************************/
#define sk_family		family
#define sk_protocol		protocol
#define sk_route_caps		route_caps
#define sk_backlog_rcv		backlog_rcv

/******************************************************************************
 * module compatibility
 ******************************************************************************/
#define	MODULE_VERSION(x)
#define subsys_initcall	module_init

#endif /* __TOE_COMPAT_2_4_H */
