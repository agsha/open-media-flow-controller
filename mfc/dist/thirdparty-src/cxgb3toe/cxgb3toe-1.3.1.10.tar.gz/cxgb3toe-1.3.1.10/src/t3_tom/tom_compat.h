/*
 * Copyright (C) 2003-2009 Chelsio Communications.  All rights reserved.
 *
 * Written by Dimitris Michailidis (dm@chelsio.com),
 *	      Divy Le Ray (divy@chelsio.com)
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the LICENSE file included in this
 * release for licensing terms and conditions.
 */

#ifndef __TOM_COMPAT_H
#define __TOM_COMPAT_H

#include <linux/version.h>

/*
 * Pull in either Linux 2.6 or earlier compatibility definitions.
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#include "tom_compat_2_6.h"
#else
#include "tom_compat_2_4.h"
#endif

#ifdef CONFIG_DEBUG_FS
#include <linux/debugfs.h>
#endif

#if !defined(NEW_SKB_OFFSET)
static inline void skb_reset_transport_header(struct sk_buff *skb)
{
	skb->h.raw = skb->data;
}

#if !defined(T3_TCP_HDR)
static inline struct tcphdr *tcp_hdr(const struct sk_buff *skb)
{
	return skb->h.th;
}
#endif
#endif

#if !defined(SEC_INET_CONN_REQUEST)
static inline int security_inet_conn_request(struct sock *sk,
					     struct sk_buff *skb,
					     struct request_sock *req)
{
	return 0;
}
#endif

#if defined(OLD_OFFLOAD_H)
/*
 * Extended 'struct proto' with additional members used by offloaded
 * connections.
 */
struct sk_ofld_proto {
        struct proto proto;    /* keep this first */
        int (*read_sock)(struct sock *sk, read_descriptor_t *desc,
                         sk_read_actor_t recv_actor);
};

#if defined(CONFIG_TCP_OFFLOAD_MODULE)
extern int  install_special_data_ready(struct sock *sk);
extern void restore_special_data_ready(struct sock *sk);
#else
static inline int install_special_data_ready(struct sock *sk) { return 0; }
static inline void restore_special_data_ready(struct sock *sk) {}
#endif

#if defined(CONFIG_DEBUG_RODATA) && defined(CONFIG_TCP_OFFLOAD_MODULE)
extern void offload_socket_ops(struct sock *sk);
extern void restore_socket_ops(struct sock *sk);
#else
static inline void offload_socket_ops(struct sock *sk) {}
static inline void restore_socket_ops(struct sock *sk) {}
#endif

#endif

#if defined(DEACTIVATE_OFFLOAD)
struct toedev;
static inline int deactivate_offload(struct toedev *dev)
{
        return -1;
}
#endif

#if defined(CONFIG_KPROBES) && defined(KPROBES_SYMBOL_NAME)
#define KPROBES_KALLSYMS
#endif

#if !defined(SK_FILTER_UNCHARGE)
#define sk_filter_uncharge sk_filter_release
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,24)
#define TUNABLE_INT_CTL_NAME(name) (TOE_CONF_ ## name)
#define TUNABLE_INT_RANGE_CTL_NAME(name) (TOE_CONF_ ## name)
#define TOM_INSTANCE_DIR_CTL_NAME 1
#define ROOT_DIR_CTL_NAME CTL_TOE
#else
#define TUNABLE_INT_CTL_NAME(name) CTL_UNNUMBERED
#define TUNABLE_INT_RANGE_CTL_NAME(name) CTL_UNNUMBERED
#define TOM_INSTANCE_DIR_CTL_NAME CTL_UNNUMBERED
#define ROOT_DIR_CTL_NAME CTL_UNNUMBERED
#endif

#if defined(PPC64_TLB_BATCH_NR)
static inline void flush_tlb_mm_p(struct mm_struct *mm)
{
}

static inline void flush_tlb_page_p(struct vm_area_struct *vma,
				  unsigned long vmaddr)
{
}
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
#define SET_PROC_NODE_OWNER(_p, _owner) \
	do { (_p)->owner = (_owner); } while (0)
#else
#define SET_PROC_NODE_OWNER(_p, _owner) \
	do { } while (0)
#endif

#endif /* __TOM_COMPAT_H */
