rmmod kvm_intel
rmmod kvm
rmmod vhost_net

rmmod tun
rmmod bridge
rmmod stp
rmmod llc
