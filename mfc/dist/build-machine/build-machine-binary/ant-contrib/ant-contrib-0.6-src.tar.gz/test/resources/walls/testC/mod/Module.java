
package mod;

import mod.modA.ModuleA;
import mod.modB.ModuleB;

public class Module
{
    private ModuleA temp1;
    private ModuleB temp2;
};