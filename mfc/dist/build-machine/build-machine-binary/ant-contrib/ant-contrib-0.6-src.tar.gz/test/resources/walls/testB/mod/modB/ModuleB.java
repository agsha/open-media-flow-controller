
package mod.modB;

import mod.modA.ModuleA;

public class ModuleB
{
    private ModuleA temp;
};